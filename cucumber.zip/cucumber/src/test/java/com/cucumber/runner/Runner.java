package com.cucumber.runner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.api.utils.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/features", glue = { "com.cucumber.stepdefs" }, tags= "@smoke",
monochrome = true, dryRun = false, plugin ={"pretty" , "html:report"})
public class Runner {
	@BeforeClass
	public static void initialize() {
		Reporter.startReport();
	}
	
	@AfterClass
	public static void tearDown() {
		Reporter.flushTests();
	}
}
