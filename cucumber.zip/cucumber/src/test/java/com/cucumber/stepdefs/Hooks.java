package com.cucumber.stepdefs;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.api.utils.Reporter;
import com.aventstack.extentreports.Status;

import cucumber.api.PickleStepTestStep;
import cucumber.api.Scenario;
import cucumber.api.TestCase;
import cucumber.api.TestStep;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;

public class Hooks {
	private static final Logger logger = LoggerFactory.getLogger(Hooks.class);
	public static int currentStepIndex = 0;
	private static List<String> stepNames = new ArrayList<String>();

	@Before
	public void beforeScenario(Scenario scenario) {
		currentStepIndex = 0;
		logger.info("Scenario Started:" + scenario.getName());
		try {
			String featureName = scenario.getId().split(":")[1];
			String[] split = featureName.split("/");
			String feature = split[split.length-1].split("\\.")[0];
			Reporter.createExtentTest(scenario.getName()).assignCategory(feature);
			
			Field testCaseField = scenario.getClass().getDeclaredField("testCase");
			testCaseField.setAccessible(true);

			TestCase tc = (TestCase) testCaseField.get(scenario);
			Field testSteps = tc.getClass().getDeclaredField("testSteps");
			testSteps.setAccessible(true);

			List<TestStep> teststeps = tc.getTestSteps();

			for(TestStep testStep: teststeps) {
				if(testStep instanceof PickleStepTestStep) {
					PickleStepTestStep pts = (PickleStepTestStep) testStep;
					stepNames.add(pts.getStepText());
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	@BeforeStep
	public void beforeStep(Scenario scenario) {
		Reporter.createNode(stepNames.get(currentStepIndex));
		currentStepIndex++;
	}
	
	@AfterStep
	public void afterStep() {
	}
	
	@After
	public void afterScenario(Scenario scenario) {
		logger.info("Scenario Execution Completed:" + scenario.getName());
		if(scenario.isFailed()) {
			Reporter.logMessage(Status.FAIL, "Scenario Failed");
		}else {
			Reporter.logMessage(Status.PASS, "Scenario Passed");
		}
		stepNames.clear();
	}
}
