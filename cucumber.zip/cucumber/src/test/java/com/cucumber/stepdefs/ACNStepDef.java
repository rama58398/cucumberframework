package com.cucumber.stepdefs;

import com.api.exceptions.FrameworkException;
import com.api.pojo.TestData;
import com.api.services.factory.APITest;
import com.api.utils.Reporter;
import com.aventstack.extentreports.Status;

import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;

public class ACNStepDef implements En {

	public ACNStepDef(BaseSteps baseSteps, APITest apiTest, TestData testData) {
		Given("there is an active vehicle", (DataTable dataTable) -> {
			try {
				testData.setBaseURL(baseSteps.getColValFromDataTable(dataTable, "BaseUrl"));
				testData.setRequestURL(baseSteps.getColValFromDataTable(dataTable, "RequestUrl"));
				testData.setRequestMethod(baseSteps.getColValFromDataTable(dataTable, "ReqMethod"));
				testData.setRequestParameters("imei=" + baseSteps.getColValFromDataTable(dataTable, "IMEI"));
				testData.setContentType("application/json");
				
				Response response = apiTest.invokeService(testData);
				
				testData.setExpectedResponseCode("200");
				testData.setExpectedResponse("sim.imei=" + baseSteps.getColValFromDataTable(dataTable, "IMEI"));
				apiTest.validateResponse(response, testData);
				
				baseSteps.setdependentTestData("IMEI", baseSteps.getValueFromJsonResponse(response, "sim.imei"));
				baseSteps.setdependentTestData("VIN", baseSteps.getValueFromJsonResponse(response, "vin"));
				baseSteps.setdependentTestData("SIMID", baseSteps.getValueFromJsonResponse(response, "sim.iccid"));
			} catch (Exception e) {
				Reporter.logMessage(Status.FAIL, "Failed while fetching active vehicle </br>" + e);
				throw new FrameworkException("Failed while fetching active vehicle", e);
			}
		});

		When("the vehicle initiates an ACN", (DataTable dataTable) -> {
			try {
				testData.setBaseURL(baseSteps.getColValFromDataTable(dataTable, "BaseUrl"));
				testData.setRequestURL(baseSteps.getColValFromDataTable(dataTable, "RequestUrl"));
				testData.setRequestMethod(baseSteps.getColValFromDataTable(dataTable, "ReqMethod"));
				testData.setRequestBody("/rvm/rvm.xml");
				testData.setContentType("application/xml");
				
				String imei = baseSteps.getdependentTestData("IMEI");
				String vin = baseSteps.getdependentTestData("VIN");
				String simId = baseSteps.getdependentTestData("SIMID");
				testData.addDynamicKeys("IMEI", imei)
				        .addDynamicKeys("VIN", vin)
				        .addDynamicKeys("SIMID", simId)
				        .addDynamicKeys("Datetime", baseSteps.getUTCDate());
				Response response = apiTest.invokeService(testData);
				testData.setExpectedResponseCode("200");
				apiTest.validateResponse(response, testData);
			} catch (Exception e) {
				Reporter.logMessage(Status.FAIL, "Failed while fetching active vehicle </br>" + e);
				throw new FrameworkException("Failed while fetching active vehicle", e);
			}
		});

		When("the call gets routed", () -> {
		});

		When("the event details are requested", () -> {
		});

		When("the Call Agent terminates the call", () -> {
		});

		When("the vehicle confirms intentional call termination", () -> {
		});

		Then("the ACN event should not be active", () -> {
		});
	}
}
