package com.cucumber.stepdefs;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;

public class BaseSteps {
	
	public static Map<String, Object> dependentTestData = Collections.synchronizedMap(new LinkedHashMap<>());
	
	public String getColValFromDataTable(DataTable dataTable, String colName) {
		List<Map<String, String>> data =  dataTable.asMaps(String.class, String.class);
		return data.get(0).get(colName);
	}
	
	public void setdependentTestData(String testName, Object object) {
		dependentTestData.put(testName, object);
	}
	
	public Map<String, Object> getdependentTestData() {
		return dependentTestData;
	}
	
	public String getdependentTestData(String key) {
		return (String) dependentTestData.get(key);
	}
	
	public String getUTCDate() {
		Date dt = new Date();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		String utcDate = dateFormatter.format(dt);
		return utcDate;
	}

	public String getValueFromJsonResponse(Response response, String path) {
		return response.jsonPath().getString(path);
	}
}
